const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs');
const URL = 'http://localhost:5055/lab3';
const OUT = '../evidence/';
const log = [];
const L = s => { console.log(s); log.push(s); };
async function fill(page, o) {
  await page.fill('#student-id', o.sid); await page.fill('#full-name', o.name);
  await page.selectOption('#course', 'BSc Information Technology');
  await page.check('#floor-' + o.floor); await page.selectOption('#seat', o.seat);
  await page.selectOption('#duration', '2'); await page.check('#consent');
}
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 } });
  const page = await ctx.newPage();
  let apiCalls = 0; page.on('request', r => { if (r.url().includes('/api/lab3/checkin')) apiCalls++; });

  // A. Client-side validation stops the request
  await page.goto(URL);
  await page.click('#submit-btn');
  await page.waitForTimeout(400);
  L('A. Empty form submitted: API requests sent = ' + apiCalls + ' (expected 0); error summary visible = ' + await page.isVisible('#error-summary'));
  await page.fill('#student-id', '2023'); await page.fill('#full-name', 'Dennis Sampa');
  await page.click('#submit-btn'); await page.waitForTimeout(300);
  L('A2. Invalid Student ID "2023": API requests sent = ' + apiCalls + ' (expected 0)');
  await page.screenshot({ path: OUT + 'l3_client_blocked.png', fullPage: true });

  // B. Loading state (delay the response so it can be captured)
  await page.goto(URL);
  await page.route('**/api/lab3/checkin', async route => { await new Promise(r => setTimeout(r, 1500)); route.continue(); });
  await fill(page, { sid: '202302571', name: 'Dennis Sampa', floor: 'ground', seat: 'G12' });
  await page.click('#submit-btn'); await page.waitForTimeout(500);
  L('B. During request: button disabled = ' + await page.isDisabled('#submit-btn') + ', label = "' + (await page.textContent('#submit-label')).trim() + '", aria-busy = ' + await page.getAttribute('#submit-btn', 'aria-busy') + ', status = "' + (await page.textContent('#form-status')).trim() + '"');
  await page.screenshot({ path: OUT + 'l3_loading.png', clip: { x: 0, y: 380, width: 1100, height: 520 } });
  await page.waitForSelector('#result:not([hidden])');
  L('C. After success: result visible = true, label = "' + (await page.textContent('#submit-label')).trim() + '", status = "' + (await page.textContent('#form-status')).trim() + '"');
  L('   Response shown on page: ' + (await page.textContent('#result-json')).replace(/\s+/g, ' ').slice(0, 220));
  await page.screenshot({ path: OUT + 'l3_success.png', fullPage: true });

  // D. Server-side rejection that the client cannot know about (seat already taken)
  await page.unroute('**/api/lab3/checkin');
  await page.goto(URL);
  await fill(page, { sid: '202302133', name: 'Gift Saya', floor: 'ground', seat: 'G12' });
  await page.click('#submit-btn'); await page.waitForSelector('#error-summary:not([hidden])');
  await page.waitForTimeout(300);
  L('D. Seat already taken: summary title = "' + (await page.textContent('#error-summary-title')).trim() + '"');
  L('   seat aria-invalid = ' + await page.getAttribute('#seat', 'aria-invalid') + ', seat error = "' + (await page.textContent('#seat-error')).trim() + '"');
  L('   status = "' + (await page.textContent('#form-status')).trim() + '"');
  await page.screenshot({ path: OUT + 'l3_server_error.png', fullPage: true });

  // E. Network failure
  await page.goto(URL);
  await page.route('**/api/lab3/checkin', r => r.abort());
  await fill(page, { sid: '202302999', name: 'Test Student', floor: 'second', seat: 'S9' });
  await page.click('#submit-btn'); await page.waitForSelector('#error-summary:not([hidden])');
  L('E. Network down: summary title = "' + (await page.textContent('#error-summary-title')).trim() + '", message = "' + (await page.textContent('#error-summary-list')).trim() + '", button re-enabled = ' + !(await page.isDisabled('#submit-btn')));
  await page.screenshot({ path: OUT + 'l3_network_error.png', clip: { x: 0, y: 80, width: 1100, height: 520 } });
  await page.unroute('**/api/lab3/checkin');

  // F. Bypass the client: call the API from the console with an invalid payload
  const bypass = await page.evaluate(async () => {
    const res = await fetch('/api/lab3/checkin', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ student_id: '12', full_name: '<script>alert(1)</script>', course: 'Other', floor: 'ground', seat_number: 'G1', planned_hours: 99, location_consent: true }) });
    return { status: res.status, ct: res.headers.get('content-type'), body: await res.json() };
  });
  L('F. Console fetch bypassing client validation: HTTP ' + bypass.status + ' ' + bypass.ct + ' fields rejected = ' + Object.keys(bypass.body.errors).join(', '));

  // G. Latency profile: 60 rejected + 1 accepted-type requests measured in the browser
  const lat = await page.evaluate(async () => {
    const bad = JSON.stringify({ student_id: '1' }), times = [];
    for (let i = 0; i < 60; i++) { const t = performance.now(); const r = await fetch('/api/lab3/checkin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: bad }); await r.json(); times.push(performance.now() - t); }
    times.sort((a, b) => a - b);
    return { n: times.length, mean: times.reduce((a, b) => a + b) / times.length, median: times[30], p95: times[Math.floor(times.length * 0.95)], max: times[times.length - 1] };
  });
  L('G. Latency of 60 validation round trips (422): mean ' + lat.mean.toFixed(1) + ' ms, median ' + lat.median.toFixed(1) + ' ms, p95 ' + lat.p95.toFixed(1) + ' ms, max ' + lat.max.toFixed(1) + ' ms');
  fs.writeFileSync(OUT + 'browser_tests.txt', log.join('\n') + '\n');
  await browser.close();
})();
