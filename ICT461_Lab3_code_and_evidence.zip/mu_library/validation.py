"""Server-side validation and sanitisation for the Lab 3 check-in endpoint.

Defence in depth: nothing here trusts the browser. Every rule is applied again
even though the client-side script (static/lab3.js) already checks the same fields.
"""
import html
import re
import unicodedata

from database import FLOORS, MAX_SESSION_MINUTES

COURSES = ["BSc Computer Science", "BSc Information Technology", "BEng Engineering",
           "Business and Management", "Education", "Other"]
NEEDS = {"power", "quiet", "step-free"}
ALLOWED_FIELDS = {"student_id", "full_name", "phone", "course", "floor", "seat_number",
                  "needs", "planned_hours", "notes", "location_consent"}
REQUIRED_FIELDS = ["student_id", "full_name", "course", "floor", "seat_number",
                   "planned_hours", "location_consent"]

STUDENT_ID_RE = re.compile(r"^\d{9}$")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'\-]{1,59}$")
PHONE_RE = re.compile(r"^(\+260|0)(9|7)\d{8}$")
TAG_RE = re.compile(r"<[^>]*>")
CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def sanitise_text(value):
    """Normalise, strip control characters and HTML tags, collapse spaces, then HTML-escape."""
    value = unicodedata.normalize("NFKC", str(value))
    value = CONTROL_RE.sub("", value)
    value = TAG_RE.sub("", value)
    value = re.sub(r"[ \t]+", " ", value).strip()
    return html.escape(value, quote=True)


def validate_checkin(payload):
    """Return (clean, errors). errors maps field -> message; clean is only usable if errors is empty."""
    errors, clean = {}, {}
    if not isinstance(payload, dict):
        return {}, {"_body": "Request body must be a JSON object."}

    for key in payload:
        if key not in ALLOWED_FIELDS:
            errors[key] = "Unknown field. Remove it from the request."

    for key in REQUIRED_FIELDS:
        if key not in payload or payload[key] in ("", None):
            errors.setdefault(key, "This field is required.")

    def text(key):
        v = payload.get(key)
        return v if isinstance(v, str) else None

    sid = payload.get("student_id")
    if "student_id" not in errors:
        if not isinstance(sid, str) or not STUDENT_ID_RE.fullmatch(sid):
            errors["student_id"] = "Student ID must be exactly 9 digits."
        else:
            clean["student_id"] = sid

    if "full_name" not in errors:
        name = text("full_name")
        name = re.sub(r"\s+", " ", name).strip() if name is not None else None
        if name is None or not NAME_RE.fullmatch(name):
            errors["full_name"] = "Full name must be 2 to 60 characters: letters, spaces, hyphens and apostrophes only."
        else:
            clean["full_name"] = sanitise_text(name)

    if payload.get("phone") not in (None, ""):
        ph = payload.get("phone")
        if not isinstance(ph, str) or not PHONE_RE.fullmatch(ph.replace(" ", "")):
            errors["phone"] = "Use a Zambian mobile number such as 0971234567 or +260971234567."
        else:
            clean["phone"] = ph.replace(" ", "")

    if "course" not in errors:
        if payload.get("course") not in COURSES:
            errors["course"] = "Choose a programme from the list."
        else:
            clean["course"] = payload["course"]

    floor = payload.get("floor")
    if "floor" not in errors:
        if floor not in FLOORS:
            errors["floor"] = "Floor must be one of: " + ", ".join(FLOORS) + "."
        else:
            clean["floor"] = floor

    if "seat_number" not in errors:
        seat = payload.get("seat_number")
        m = re.fullmatch(r"([GFS])(\d{1,2})", seat) if isinstance(seat, str) else None
        if not m or not 1 <= int(m.group(2)) <= 40:
            errors["seat_number"] = "Seat must look like G12, F7 or S40 (1 to 40)."
        elif "floor" in clean and m.group(1) != FLOORS[clean["floor"]]["prefix"]:
            errors["seat_number"] = "Seat letter does not match the chosen floor."
        else:
            clean["seat_number"] = seat

    needs = payload.get("needs", [])
    if not isinstance(needs, list) or not all(isinstance(n, str) and n in NEEDS for n in needs):
        errors["needs"] = "Needs must be a list containing only: power, quiet, step-free."
    else:
        clean["needs"] = sorted(set(needs))

    if "planned_hours" not in errors:
        h = payload.get("planned_hours")
        if isinstance(h, bool) or not isinstance(h, int) or not 1 <= h <= MAX_SESSION_MINUTES // 60:
            errors["planned_hours"] = f"Planned stay must be a whole number from 1 to {MAX_SESSION_MINUTES // 60} hours."
        else:
            clean["planned_hours"] = h

    notes = payload.get("notes", "")
    if notes in (None, ""):
        clean["notes"] = ""
    elif not isinstance(notes, str) or len(notes) > 200:
        errors["notes"] = "Notes must be text of at most 200 characters."
    else:
        clean["notes"] = sanitise_text(notes)

    if "location_consent" not in errors and payload.get("location_consent") is not True:
        errors["location_consent"] = "You must agree to location and check-in time being recorded."
    else:
        clean["location_consent"] = True

    return clean, errors
