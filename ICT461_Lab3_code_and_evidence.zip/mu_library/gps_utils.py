import math

# ─────────────────────────────────────────────
# Mulungushi University Library GPS Coordinates
# Kabwe, Zambia
# Update these to the exact library building centre
# ─────────────────────────────────────────────
LIBRARY_LATITUDE  = -14.2962613
LIBRARY_LONGITUDE =  28.5605971
LIBRARY_RADIUS_METRES = 2000  # Adjust as needed (100m is generous for indoors)


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great-circle distance in metres between two GPS points.
    Uses the Haversine formula — no external libraries needed.
    """
    R = 6_371_000  # Earth radius in metres

    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi       = math.radians(lat2 - lat1)
    d_lambda    = math.radians(lon2 - lon1)

    a = (math.sin(d_phi / 2) ** 2
         + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2)

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def is_inside_library(student_lat: float, student_lon: float) -> dict:
    """
    Check if the student's GPS position is within the library boundary.
    Returns a dict with allowed status, distance, and a message.
    """
    distance = haversine_distance(
        student_lat, student_lon,
        LIBRARY_LATITUDE, LIBRARY_LONGITUDE
    )

    if distance <= LIBRARY_RADIUS_METRES:
        return {
            "allowed": True,
            "distance_metres": round(distance, 1),
            "message": "Location verified. You are inside the library."
        }
    else:
        return {
            "allowed": False,
            "distance_metres": round(distance, 1),
            "message": (
                f"You appear to be {round(distance)} metres from the library. "
                f"You must be physically inside to check in."
            )
        }