import sqlite3
from datetime import datetime, time as dtime

DB_PATH = "library.db"

# ─── Seat rules (from the MU Library Seat Management design) ───
MAX_SESSION_MINUTES   = 180   # one check-in lasts at most 3 hours
AWAY_LIMIT_MINUTES    = 20    # a student may step away for at most 20 minutes
PING_INTERVAL_MINUTES = 45    # "Still here?" prompt interval
PING_GRACE_MINUTES    = 10    # time allowed to answer the prompt

# Library closing times (24hr)
LIBRARY_HOURS = {
    0: ("07:00", "22:00"),  # Monday
    1: ("07:00", "22:00"),
    2: ("07:00", "22:00"),
    3: ("07:00", "22:00"),
    4: ("07:00", "22:00"),
    5: ("08:00", "18:00"),  # Saturday
    6: None,                # Sunday - closed
}

FLOORS = {
    "ground": {"label": "Ground Floor", "prefix": "G", "seats": 40},
    "first":  {"label": "1st Floor",    "prefix": "F", "seats": 40},
    "second": {"label": "2nd Floor",    "prefix": "S", "seats": 40},
}


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS active_sessions (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id    TEXT    NOT NULL UNIQUE,
            full_name     TEXT    NOT NULL,
            course        TEXT,
            floor         TEXT,
            seat_number   TEXT,
            check_in_time TEXT    NOT NULL,
            last_activity TEXT,
            latitude      REAL,
            longitude     REAL
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS session_history (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            full_name        TEXT    NOT NULL,
            course           TEXT,
            floor            TEXT,
            seat_number      TEXT,
            check_in_time    TEXT    NOT NULL,
            check_out_time   TEXT    NOT NULL,
            duration_seconds INTEGER NOT NULL,
            checkout_reason  TEXT    DEFAULT 'manual',
            latitude         REAL,
            longitude        REAL
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS out_of_service (
            floor       TEXT NOT NULL,
            seat_number TEXT NOT NULL,
            reason      TEXT,
            marked_at   TEXT NOT NULL,
            PRIMARY KEY (floor, seat_number)
        )
    """)
    # Migrate older databases
    existing = [r[1] for r in c.execute("PRAGMA table_info(active_sessions)")]
    for col, typ in [("floor","TEXT"),("seat_number","TEXT"),("last_activity","TEXT"),
                     ("status","TEXT DEFAULT 'present'"),("away_since","TEXT")]:
        if col not in existing:
            c.execute(f"ALTER TABLE active_sessions ADD COLUMN {col} {typ}")
    existing_h = [r[1] for r in c.execute("PRAGMA table_info(session_history)")]
    for col, typ in [("floor","TEXT"),("seat_number","TEXT"),("checkout_reason","TEXT")]:
        if col not in existing_h:
            c.execute(f"ALTER TABLE session_history ADD COLUMN {col} {typ}")

    c.execute("UPDATE active_sessions SET last_activity = check_in_time WHERE last_activity IS NULL")
    c.execute("UPDATE active_sessions SET status = 'present' WHERE status IS NULL")
    conn.commit()
    conn.close()


# ─── Check in / out ───────────────────────────────────
def checkin_student(student_id, full_name, course, floor, seat_number, latitude, longitude):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.now().isoformat()
    try:
        c.execute("""INSERT INTO active_sessions
            (student_id,full_name,course,floor,seat_number,check_in_time,last_activity,latitude,longitude,status)
            VALUES (?,?,?,?,?,?,?,?,?,'present')""",
            (student_id,full_name,course,floor,seat_number,now,now,latitude,longitude))
        conn.commit()
        return {"success": True, "check_in_time": now}
    except sqlite3.IntegrityError:
        return {"success": False, "error": "This Student ID is already checked in."}
    finally:
        conn.close()


def checkout_student(student_id, reason="manual"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM active_sessions WHERE student_id = ?", (student_id,))
    session = c.fetchone()
    if not session:
        conn.close()
        return {"success": False, "error": "No active session found."}
    now = datetime.now().isoformat()
    duration = int((datetime.fromisoformat(now) - datetime.fromisoformat(session["check_in_time"])).total_seconds())
    c.execute("""INSERT INTO session_history
        (student_id,full_name,course,floor,seat_number,check_in_time,check_out_time,duration_seconds,checkout_reason,latitude,longitude)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (session["student_id"],session["full_name"],session["course"],session["floor"],
         session["seat_number"],session["check_in_time"],now,duration,reason,session["latitude"],session["longitude"]))
    c.execute("DELETE FROM active_sessions WHERE student_id = ?", (student_id,))
    conn.commit()
    conn.close()
    return {"success": True, "duration_seconds": duration, "check_out_time": now}


def checkout_all(reason="auto_closing_time"):
    """Logout every active session — used at library closing time."""
    sessions = get_active_sessions()
    for s in sessions:
        checkout_student(s["student_id"], reason=reason)
    return len(sessions)


# ─── Presence: "Still here?" and "Step away" ──────────
def update_activity(student_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE active_sessions SET last_activity = ? WHERE student_id = ?",
              (datetime.now().isoformat(), student_id))
    updated = c.rowcount
    conn.commit()
    conn.close()
    return updated > 0


def set_away(student_id):
    """Student taps 'Step away': starts the 20-minute away countdown."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT status FROM active_sessions WHERE student_id = ?", (student_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        return {"success": False, "error": "No active session found."}
    if row["status"] == "away":
        conn.close()
        return {"success": False, "error": "You are already marked as away."}
    now = datetime.now().isoformat()
    c.execute("UPDATE active_sessions SET status='away', away_since=? WHERE student_id=?", (now, student_id))
    conn.commit()
    conn.close()
    return {"success": True, "away_since": now, "away_limit_minutes": AWAY_LIMIT_MINUTES}


def set_back(student_id):
    """Student taps 'I'm back': clears the away countdown."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT status FROM active_sessions WHERE student_id = ?", (student_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        return {"success": False, "error": "Your seat was released while you were away."}
    now = datetime.now().isoformat()
    c.execute("UPDATE active_sessions SET status='present', away_since=NULL, last_activity=? WHERE student_id=?",
              (now, student_id))
    conn.commit()
    conn.close()
    return {"success": True}


# ─── Queries ──────────────────────────────────────────
def get_active_sessions():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM active_sessions ORDER BY check_in_time DESC")
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_session(student_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM active_sessions WHERE student_id = ?", (student_id,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None


def is_already_checked_in(student_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT 1 FROM active_sessions WHERE student_id = ?", (student_id,))
    result = c.fetchone() is not None
    conn.close()
    return result


def is_seat_taken(floor, seat_number):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT 1 FROM active_sessions WHERE floor=? AND seat_number=?", (floor, seat_number))
    result = c.fetchone() is not None
    conn.close()
    return result


def get_occupied_seats(floor):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT seat_number FROM active_sessions WHERE floor = ?", (floor,))
    seats = [r["seat_number"] for r in c.fetchall()]
    conn.close()
    return seats


def get_seat_states(floor):
    """Return {seat_id: {status, student_id, full_name, away_since, check_in_time}} for one floor.
    status is 'occupied', 'away' or 'out_of_service'. Free seats are not listed."""
    conn = get_connection()
    c = conn.cursor()
    states = {}
    c.execute("SELECT * FROM active_sessions WHERE floor = ?", (floor,))
    for r in c.fetchall():
        states[r["seat_number"]] = {
            "status": "away" if r["status"] == "away" else "occupied",
            "student_id": r["student_id"],
            "full_name": r["full_name"],
            "away_since": r["away_since"],
            "check_in_time": r["check_in_time"],
        }
    c.execute("SELECT * FROM out_of_service WHERE floor = ?", (floor,))
    for r in c.fetchall():
        states[r["seat_number"]] = {"status": "out_of_service", "reason": r["reason"]}
    conn.close()
    return states


# ─── Librarian controls ───────────────────────────────
def is_seat_out_of_service(floor, seat_number):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT 1 FROM out_of_service WHERE floor=? AND seat_number=?", (floor, seat_number))
    result = c.fetchone() is not None
    conn.close()
    return result


def mark_seat_vacant(floor, seat_number, reason="force_librarian"):
    """Librarian frees a seat: ends the session of whoever holds it."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT student_id FROM active_sessions WHERE floor=? AND seat_number=?", (floor, seat_number))
    row = c.fetchone()
    conn.close()
    if not row:
        return {"success": False, "error": "That seat is already free."}
    return checkout_student(row["student_id"], reason=reason)


def set_out_of_service(floor, seat_number, reason=""):
    if is_seat_taken(floor, seat_number):
        return {"success": False, "error": "Seat is occupied. Mark it vacant first."}
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO out_of_service (floor,seat_number,reason,marked_at) VALUES (?,?,?,?)",
              (floor, seat_number, reason, datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return {"success": True}


def restore_seat(floor, seat_number):
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM out_of_service WHERE floor=? AND seat_number=?", (floor, seat_number))
    removed = c.rowcount
    conn.commit()
    conn.close()
    if not removed:
        return {"success": False, "error": "Seat is not out of service."}
    return {"success": True}


# ─── Automatic release rules ──────────────────────────
def is_library_closed():
    """Returns True if current time is outside library hours."""
    now = datetime.now()
    hours = LIBRARY_HOURS.get(now.weekday())
    if hours is None:
        return True  # Sunday
    open_t = datetime.strptime(hours[0], "%H:%M").time()
    close_t = datetime.strptime(hours[1], "%H:%M").time()
    return not (open_t <= now.time() <= close_t)


def cleanup_expired_sessions():
    """
    Automatically release seats when:
    1. The library is closed (everyone is checked out)
    2. A student has been away for more than AWAY_LIMIT_MINUTES (20)
    3. A session has lasted MAX_SESSION_MINUTES (3 hours)
    4. A "Still here?" prompt has gone unanswered for PING_GRACE_MINUTES
    """
    sessions = get_active_sessions()
    now = datetime.now()
    checked_out = []

    if is_library_closed() and sessions:
        n = checkout_all(reason="auto_closing_time")
        return [f"closing_time_{i}" for i in range(n)]

    for s in sessions:
        try:
            check_in = datetime.fromisoformat(s["check_in_time"])
            last_act = datetime.fromisoformat(s.get("last_activity") or s["check_in_time"])
            minutes_in = (now - check_in).total_seconds() / 60
            mins_since_activity = (now - last_act).total_seconds() / 60

            reason = None
            if s.get("status") == "away" and s.get("away_since"):
                away_for = (now - datetime.fromisoformat(s["away_since"])).total_seconds() / 60
                if away_for >= AWAY_LIMIT_MINUTES:
                    reason = "auto_away"
            if reason is None and minutes_in >= MAX_SESSION_MINUTES:
                reason = "auto_max_time"
            if (reason is None and s.get("status") != "away"
                    and mins_since_activity >= PING_INTERVAL_MINUTES + PING_GRACE_MINUTES):
                reason = "auto_inactive"

            if reason:
                checkout_student(s["student_id"], reason=reason)
                checked_out.append(s["student_id"])
        except Exception as e:
            print(f"Cleanup error for {s.get('student_id')}: {e}")

    return checked_out


# ─── Reports ──────────────────────────────────────────
def get_session_history(limit=200):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM session_history ORDER BY check_out_time DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_stats():
    conn = get_connection()
    c = conn.cursor()
    today = datetime.now().date().isoformat()
    c.execute("SELECT COUNT(*) as cnt FROM active_sessions")
    current = c.fetchone()["cnt"]
    c.execute("SELECT COUNT(*) as cnt FROM active_sessions WHERE status='away'")
    away = c.fetchone()["cnt"]
    c.execute("SELECT COUNT(*) as cnt FROM session_history WHERE DATE(check_in_time)=?", (today,))
    today_cnt = c.fetchone()["cnt"]
    c.execute("SELECT COUNT(*) as cnt FROM session_history WHERE DATE(check_out_time)=? AND checkout_reason LIKE 'auto_%'", (today,))
    auto_today = c.fetchone()["cnt"]
    c.execute("SELECT AVG(duration_seconds) as avg FROM session_history")
    avg_row = c.fetchone()
    avg = int(avg_row["avg"]) if avg_row["avg"] else 0
    c.execute("SELECT COUNT(*) as cnt FROM session_history")
    total = c.fetchone()["cnt"]
    c.execute("SELECT COUNT(*) as cnt FROM out_of_service")
    oos = c.fetchone()["cnt"]
    conn.close()
    return {"current_occupancy": current, "away_now": away, "sessions_today": today_cnt,
            "auto_releases_today": auto_today, "out_of_service": oos,
            "avg_duration_seconds": avg, "total_sessions": total}


def get_chart_data():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT floor, COUNT(*) as cnt FROM session_history WHERE floor IS NOT NULL GROUP BY floor")
    floor_rows = {r["floor"]: r["cnt"] for r in c.fetchall()}
    sessions_per_floor = {"Ground Floor": floor_rows.get("ground",0), "1st Floor": floor_rows.get("first",0), "2nd Floor": floor_rows.get("second",0)}
    c.execute("SELECT strftime('%H', check_in_time) as hr, COUNT(*) as cnt FROM session_history GROUP BY hr ORDER BY hr")
    hour_data = {int(r["hr"]): r["cnt"] for r in c.fetchall()}
    active_hours = [hour_data.get(h, 0) for h in range(24)]
    c.execute("SELECT DATE(check_in_time) as day, COUNT(*) as cnt FROM session_history WHERE check_in_time >= date('now','-7 days') GROUP BY day ORDER BY day")
    day_rows = c.fetchall()
    conn.close()
    return {
        "sessions_per_floor": sessions_per_floor,
        "active_hours": active_hours,
        "occupancy_days": [r["day"] for r in day_rows],
        "occupancy_counts": [r["cnt"] for r in day_rows],
    }
