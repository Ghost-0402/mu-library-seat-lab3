/* MU Library check-in form (Lab 3): client-side validation (UX layer) + asynchronous Fetch submission.
   The server re-validates everything (validation.py); this script only gives faster feedback.
   Client-side validation with WAI-ARIA
   - aria-invalid toggled per field (true when failing, false when fixed)
   - visible error text linked with aria-describedby
   - role="alert" error summary + aria-live="polite" status region */
(function () {
  'use strict';

  var form = document.getElementById('checkin-form');
  var summary = document.getElementById('error-summary');
  var summaryList = document.getElementById('error-summary-list');
  var statusEl = document.getElementById('form-status');
  var result = document.getElementById('result');
  var resultJson = document.getElementById('result-json');
  var seatSelect = document.getElementById('seat');
  var notes = document.getElementById('notes');
  var notesCount = document.getElementById('notes-count');

  var FLOORS = { ground: { label: 'Ground floor', prefix: 'G' },
                 first:  { label: '1st floor',    prefix: 'F' },
                 second: { label: '2nd floor',    prefix: 'S' } };
  var SEATS_PER_FLOOR = 40;

  var ID_RE = /^\d{9}$/;
  var NAME_RE = /^[A-Za-z][A-Za-z .'\-]+$/;
  var PHONE_RE = /^(\+260|0)(9|7)\d{8}$/;

  /* Rules: return an error message, or '' when valid */
  var rules = {
    'student-id': function (v) {
      if (!v) return 'Enter your student ID.';
      if (!/^\d+$/.test(v)) return 'Student ID must contain digits only.';
      if (!ID_RE.test(v)) return 'Student ID must be exactly 9 digits. You have entered ' + v.length + '.';
      return '';
    },
    'full-name': function (v) {
      v = v.trim();
      if (!v) return 'Enter your full name.';
      if (v.length < 2) return 'Full name must be at least 2 characters.';
      if (v.length > 60) return 'Full name must be 60 characters or fewer.';
      if (!NAME_RE.test(v)) return 'Full name can contain letters, spaces, hyphens and apostrophes only.';
      return '';
    },
    'phone': function (v) {
      v = v.replace(/\s+/g, '');
      if (!v) return '';                        /* optional */
      if (!PHONE_RE.test(v)) return 'Enter a number like 0971234567 or +260971234567.';
      return '';
    },
    'course': function (v) { return v ? '' : 'Select your programme of study.'; },
    'seat': function (v) { return v ? '' : 'Select a seat.'; },
    'duration': function (v) { return v ? '' : 'Select how long you plan to stay.'; },
    'notes': function (v) { return v.length > 200 ? 'Notes must be 200 characters or fewer.' : ''; }
  };

  function $(id) { return document.getElementById(id); }

  function setFieldError(id, message) {
    var input = $(id), err = $(id + '-error');
    if (!input || !err) return;
    if (message) {
      input.setAttribute('aria-invalid', 'true');
      err.textContent = message;
      err.hidden = false;
    } else {
      input.setAttribute('aria-invalid', 'false');
      err.textContent = '';
      err.hidden = true;
    }
  }

  function validateField(id) {
    var input = $(id);
    var message = rules[id](input.value);
    setFieldError(id, message);
    return message;
  }

  function validateFloor() {
    var fs = form.querySelector('[data-group="floor"]');
    var checked = form.querySelector('input[name="floor"]:checked');
    var err = $('floor-error');
    if (!checked) {
      fs.setAttribute('aria-invalid', 'true');
      err.textContent = 'Select a floor.'; err.hidden = false;
      return 'Select a floor.';
    }
    fs.setAttribute('aria-invalid', 'false'); err.textContent = ''; err.hidden = true;
    return '';
  }

  function validateConsent() {
    var c = $('consent');
    var msg = c.checked ? '' : 'You must allow the location check to check in.';
    setFieldError('consent', msg);
    return msg;
  }

  /* Seat list depends on the floor */
  function populateSeats(floorKey) {
    var f = FLOORS[floorKey];
    seatSelect.innerHTML = '';
    var first = document.createElement('option');
    first.value = ''; first.textContent = 'Select a seat on the ' + f.label.toLowerCase();
    seatSelect.appendChild(first);
    for (var i = 1; i <= SEATS_PER_FLOOR; i++) {
      var o = document.createElement('option');
      o.value = f.prefix + i; o.textContent = 'Seat ' + f.prefix + i;
      seatSelect.appendChild(o);
    }
    seatSelect.disabled = false;
    setFieldError('seat', '');
    announce(f.label + ' selected. ' + SEATS_PER_FLOOR + ' seats listed.');
  }

  function announce(text) {
    statusEl.textContent = '';
    window.setTimeout(function () { statusEl.textContent = text; }, 50);
  }

  /* Real-time validation: on blur first, then on every input once touched */
  ['student-id', 'full-name', 'phone', 'notes'].forEach(function (id) {
    var el = $(id), touched = false;
    el.addEventListener('blur', function () { touched = true; validateField(id); });
    el.addEventListener('input', function () { if (touched || el.getAttribute('aria-invalid') === 'true') validateField(id); });
  });
  ['course', 'seat', 'duration'].forEach(function (id) {
    $(id).addEventListener('change', function () { validateField(id); });
  });
  $('consent').addEventListener('change', validateConsent);

  Array.prototype.forEach.call(form.querySelectorAll('input[name="floor"]'), function (r) {
    r.addEventListener('change', function () { populateSeats(r.value); validateFloor(); });
  });

  notes.addEventListener('input', function () { notesCount.textContent = notes.value.length + ' of 200 used.'; });

  /* Submit */
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    result.hidden = true;

    var problems = [];   /* {id, message} in DOM order */
    function check(id, message) { if (message) problems.push({ id: id, message: message }); }
    check('student-id', validateField('student-id'));
    check('full-name', validateField('full-name'));
    check('phone', validateField('phone'));
    check('course', validateField('course'));
    check('floor-ground', validateFloor());
    check('seat', seatSelect.disabled ? 'Select a seat.' : validateField('seat'));
    if (seatSelect.disabled) { setFieldError('seat', 'Select a floor first, then a seat.'); problems[problems.length - 1].message = 'Select a floor first, then a seat.'; }
    check('duration', validateField('duration'));
    check('notes', validateField('notes'));
    check('consent', validateConsent());

    if (problems.length) {
      summaryList.innerHTML = '';
      problems.forEach(function (p) {
        var li = document.createElement('li'), a = document.createElement('a');
        a.href = '#' + p.id; a.textContent = p.message;
        a.addEventListener('click', function (ev) { ev.preventDefault(); $(p.id).focus(); });
        li.appendChild(a); summaryList.appendChild(li);
      });
      $('error-summary-title').textContent = 'There ' + (problems.length === 1 ? 'is 1 problem' : 'are ' + problems.length + ' problems') + ' with your check-in';
      summary.hidden = false;
      summary.focus();                    /* role="alert" announces it; focus moves to it */
      announce(problems.length + (problems.length === 1 ? ' error' : ' errors') + ' found. Review the list at the top of the form.');
      return;
    }

    summary.hidden = true;
    var data = new FormData(form);
    var payload = {
      student_id: data.get('student_id'),
      full_name: String(data.get('full_name')).trim(),
      phone: String(data.get('phone') || '').replace(/\s+/g, ''),
      course: data.get('course'),
      floor: data.get('floor'),
      seat_number: data.get('seat_number'),
      planned_hours: Number(data.get('duration')),
      needs: data.getAll('needs'),
      notes: String(data.get('notes') || ''),
      location_consent: true
    };
    if (!payload.phone) delete payload.phone;
    sendCheckin(payload);
  });

  /* ---- Asynchronous submission (Fetch API) ---- */
  var submitBtn = $('submit-btn'), submitLabel = $('submit-label');
  var FIELD_FOR_API = { student_id: 'student-id', full_name: 'full-name', phone: 'phone', course: 'course',
                        floor: 'floor-ground', seat_number: 'seat', planned_hours: 'duration', notes: 'notes',
                        location_consent: 'consent', needs: 'need-power' };

  function setLoading(on) {
    submitBtn.disabled = on;
    submitBtn.setAttribute('aria-busy', on ? 'true' : 'false');
    submitLabel.textContent = on ? 'Checking in\u2026' : 'Check in';
    form.setAttribute('aria-busy', on ? 'true' : 'false');
    if (on) announce('Sending your check-in. Please wait.');
  }

  function showProblems(list, title) {
    summaryList.innerHTML = '';
    list.forEach(function (p) {
      var li = document.createElement('li');
      if (p.id) {
        var a = document.createElement('a');
        a.href = '#' + p.id; a.textContent = p.message;
        a.addEventListener('click', function (ev) { ev.preventDefault(); $(p.id).focus(); });
        li.appendChild(a);
      } else { li.textContent = p.message; }
      summaryList.appendChild(li);
    });
    $('error-summary-title').textContent = title;
    summary.hidden = false;
    summary.focus();
  }

  function sendCheckin(payload) {
    setLoading(true);
    var controller = new AbortController();
    var timer = window.setTimeout(function () { controller.abort(); }, 8000);   /* 8 s timeout */
    fetch('/api/lab3/checkin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json, application/problem+json' },
      body: JSON.stringify(payload),
      signal: controller.signal
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (body) { return { res: res, body: body }; });
    }).then(function (r) {
      window.clearTimeout(timer);
      if (r.res.ok) {                                             /* 201 Created */
        resultJson.textContent = JSON.stringify(r.body, null, 2);
        result.hidden = false; result.focus();
        announce('Check-in complete. Seat ' + payload.seat_number + ' is yours for up to ' + payload.planned_hours + ' hours.');
        return;
      }
      /* Server rejected the request: 400, 409, 422 ... map errors back onto the fields */
      var list = [];
      var errs = r.body.errors || {};
      Object.keys(errs).forEach(function (k) {
        var fid = FIELD_FOR_API[k];
        if (fid && k !== 'floor' && k !== 'needs') { setFieldError(fid, errs[k]); }
        list.push({ id: fid, message: errs[k] });
      });
      if (!list.length) list.push({ message: r.body.detail || ('The server returned error ' + r.res.status + '.') });
      showProblems(list, 'The server could not complete your check-in (' + r.res.status + ' ' + (r.body.title || 'Error') + ')');
      announce('Check-in failed. ' + (r.body.detail || 'Review the list at the top of the form.'));
    }).catch(function (err) {
      window.clearTimeout(timer);
      var msg = err && err.name === 'AbortError' ? 'The server took too long to respond. Please try again.'
                                                  : 'Could not reach the server. Check your connection and try again.';
      showProblems([{ message: msg }], 'Check-in not sent');
      announce(msg);
    }).then(function () { setLoading(false); });
  }

  form.addEventListener('reset', function () {
    window.setTimeout(function () {
      Object.keys(rules).forEach(function (id) { setFieldError(id, ''); });
      setFieldError('consent', '');
      var fs = form.querySelector('[data-group="floor"]'); fs.setAttribute('aria-invalid', 'false');
      $('floor-error').hidden = true;
      seatSelect.innerHTML = '<option value="">Select a floor first</option>'; seatSelect.disabled = true;
      summary.hidden = true; result.hidden = true;
      notesCount.textContent = '0 of 200 used.';
      announce('Form cleared.');
    }, 0);
  });
})();
