#!/bin/bash
# Defence-in-depth tests: requests sent straight to the server with curl, bypassing all client-side JavaScript.
U=http://localhost:5055/api/lab3/checkin
H='Content-Type: application/json'
t() {  # t "title" 'json' [extra curl args]
  echo; echo "### $1"
  echo "\$ curl -i -X POST $U -H '$H' -d '$2'"
  curl -s -i -X POST $U -H "$H" -d "$2" | grep -v -E '^(Server|Date|Connection|Content-Length):' | sed 's/\r$//'
  echo
}
OK='"full_name":"Dennis Sampa","course":"BSc Computer Science","floor":"ground","seat_number":"G12","planned_hours":2,"location_consent":true'
t "1. Valid request" "{\"student_id\":\"202302571\",$OK,\"needs\":[\"power\"],\"notes\":\"Near a socket please\"}"
t "2. Same student again (business rule, 409)" "{\"student_id\":\"202302571\",$OK}"
t "3. Different student, same seat (409)" "{\"student_id\":\"202302133\",$OK}"
t "4. Empty object (missing required fields)" '{}'
t "5. Bad formats: short ID, letters in ID, bad phone" '{"student_id":"20A","full_name":"D","phone":"12345","course":"Other","floor":"ground","seat_number":"G1","planned_hours":1,"location_consent":true}'
t "6. XSS in full_name" '{"student_id":"202302600","full_name":"<script>alert(1)</script>","course":"Other","floor":"first","seat_number":"F3","planned_hours":1,"location_consent":true}'
t "7. SQL injection in student_id" '{"student_id":"1; DROP TABLE active_sessions;--","full_name":"Test User","course":"Other","floor":"first","seat_number":"F3","planned_hours":1,"location_consent":true}'
t "8. SQL injection in seat_number" '{"student_id":"202302601","full_name":"Test User","course":"Other","floor":"first","seat_number":"F3'"'"' OR 1=1--","planned_hours":1,"location_consent":true}'
t "9. HTML/script in notes (accepted, but sanitised)" '{"student_id":"202302602","full_name":"Test User","course":"Other","floor":"first","seat_number":"F3","planned_hours":1,"location_consent":true,"notes":"<img src=x onerror=alert(1)>Quiet <b>please</b> & thanks"}'
t "10. Unknown field (mass assignment attempt)" '{"student_id":"202302603","full_name":"Test User","course":"Other","floor":"first","seat_number":"F4","planned_hours":1,"location_consent":true,"is_admin":true}'
t "11. Seat letter does not match floor" '{"student_id":"202302604","full_name":"Test User","course":"Other","floor":"first","seat_number":"G5","planned_hours":1,"location_consent":true}'
t "12. Session longer than the 3-hour rule" '{"student_id":"202302605","full_name":"Test User","course":"Other","floor":"first","seat_number":"F5","planned_hours":99,"location_consent":true}'
t "13. Wrong types (hours as text, consent as text)" '{"student_id":"202302606","full_name":"Test User","course":"Other","floor":"first","seat_number":"F6","planned_hours":"2","location_consent":"yes"}'
t "14. Malformed JSON" '{"student_id": "202302607", '
echo; echo "### 15. Wrong Content-Type"
echo "\$ curl -i -X POST $U -H 'Content-Type: text/plain' -d 'student_id=202302608'"
curl -s -i -X POST $U -H 'Content-Type: text/plain' -d 'student_id=202302608' | grep -v -E '^(Server|Date|Connection|Content-Length):' | sed 's/\r$//'
echo; echo "### 16. Oversized body (20 KB)"
echo "\$ python3 -c 'print(\"{\\\"notes\\\":\\\"\" + \"A\"*20000 + \"\\\"}\")' | curl -i -X POST $U -H '$H' --data-binary @-"
python3 -c 'print("{\"notes\":\"" + "A"*20000 + "\"}")' | curl -s -i -X POST $U -H "$H" --data-binary @- | grep -v -E '^(Server|Date|Connection|Content-Length):' | sed 's/\r$//'
echo
echo "### Database check: what was actually stored?"
echo "\$ sqlite3 library.db \"SELECT student_id, full_name, floor, seat_number FROM active_sessions\""
python3 -c "
import sqlite3; c=sqlite3.connect('/home/claude/lab3/mu_library/library.db')
for r in c.execute('SELECT student_id, full_name, floor, seat_number FROM active_sessions'): print(r)
print('tables:', [r[0] for r in c.execute(\"select name from sqlite_master where type='table'\")])"
